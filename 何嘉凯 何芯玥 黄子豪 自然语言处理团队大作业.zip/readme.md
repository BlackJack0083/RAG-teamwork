# RAG系统测试pipeline

> 请提前设置env文件，并安装好相应的依赖

您可以通过执行`main.py`文件来进行测试：

```bash
python main.py
```

如果您想进一步测试，可以修改相关参数，如：

```bash
python main.py \
    --pdf_path "./汽车介绍手册.pdf" \
    --questions_file "./QA_pairs.json" \
    --llm_model "c101-qwen25-72b" \
    --embedding_model "Qwen3-Embedding-4B" \
    --chunk_size 300 \
    --chunk_overlap 100 \
    --bm25_k 3 \
    --vector_k 3 \
    --ensemble_weights "0.5,0.5" \
    --reranker_model "bge-reranker-v2-m3" \
    --reranker_top_n 3
```

`json_extract.py`文件可以提取得到的RAG系统运行结果(以json形式存储在/rag_results中)，并将其保存为一个csv文件

`data_analysis.ipynb` 展示了一些简单的结果可视化