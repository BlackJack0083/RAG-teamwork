import argparse
import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Any

import jieba
from rouge_chinese import Rouge
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RAGEvaluator:
    def __init__(self):
        self.rouge = Rouge()
        self.smoothing_function = SmoothingFunction().method1

    def load_data(self, file_path: str) -> List[Dict[str, Any]]:
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if not isinstance(data, list):
                raise ValueError("JSON数据应为列表格式")

            logger.info(f"成功加载 {len(data)} 条数据")
            return data

        except json.JSONDecodeError as e:
            logger.error(f"JSON解析错误: {e}")
            raise
        except Exception as e:
            logger.error(f"数据加载失败: {e}")
            raise

    def _tokenize_chinese(self, text: str) -> List[str]:
        if not text or not isinstance(text, str):
            return []
        return list(jieba.cut(text.strip()))

    def compute_bleu_score(self, reference: str, hypothesis: str) -> float:
        ref_tokens = self._tokenize_chinese(reference)
        hyp_tokens = self._tokenize_chinese(hypothesis)

        if not ref_tokens or not hyp_tokens:
            return 0.0

        try:
            return sentence_bleu(
                [ref_tokens],
                hyp_tokens,
                smoothing_function=self.smoothing_function
            )
        except Exception as e:
            logger.warning(f"BLEU计算错误: {e}")
            return 0.0

    def compute_rouge_scores(self, reference: str, hypothesis: str) -> Tuple[float, float]:
        ref_tokens = self._tokenize_chinese(reference)
        hyp_tokens = self._tokenize_chinese(hypothesis)

        # 将分词结果连接为字符串
        ref_text = ' '.join(ref_tokens) if ref_tokens else ''
        hyp_text = ' '.join(hyp_tokens) if hyp_tokens else ''

        if not ref_text or not hyp_text:
            return 0.0, 0.0

        try:
            scores = self.rouge.get_scores(hyp_text, ref_text)
            rouge1_r = scores[0]["rouge-1"]["r"]
            rouge2_r = scores[0]["rouge-2"]["r"]
            return rouge1_r, rouge2_r
        except Exception as e:
            logger.warning(f"ROUGE计算错误: {e}")
            return 0.0, 0.0

    def compute_nlp_metrics(self, data: List[Dict[str, Any]]) -> Dict[str, List[float]]:

        metrics = {
            'bleu': [],
            'rouge1_r': [],
            'rouge2_r': []
        }

        for i, item in enumerate(data):
            try:
                reference = item.get("answer", "")
                hypothesis = item.get("llm_answer", "")

                # 计算BLEU分数
                bleu_score = self.compute_bleu_score(reference, hypothesis)
                metrics['bleu'].append(bleu_score)

                # 计算ROUGE分数
                rouge1_r, rouge2_r = self.compute_rouge_scores(reference, hypothesis)
                metrics['rouge1_r'].append(rouge1_r)
                metrics['rouge2_r'].append(rouge2_r)

            except Exception as e:
                logger.warning(f"第 {i + 1} 条数据处理失败: {e}")
                # 添加默认分数
                metrics['bleu'].append(0.0)
                metrics['rouge1_r'].append(0.0)
                metrics['rouge2_r'].append(0.0)

        return metrics

    def compute_reference_accuracy(self, data: List[Dict[str, Any]]) -> float:
        correct_count = 0
        total_count = 0

        for item in data:
            try:
                # 解析黄金标准页码
                reference_str = item.get("reference", "")
                if not reference_str:
                    total_count += 1
                    continue

                gold_pages = set()
                for page in reference_str.replace("page_", "").split(","):
                    page = page.strip()
                    if page:
                        gold_pages.add(page)

                # 解析预测页码
                llm_reference_str = item.get("llm_reference", "")
                if llm_reference_str:
                    pred_page = llm_reference_str.replace("page_", "").strip()
                    if pred_page in gold_pages:
                        correct_count += 1

                total_count += 1

            except Exception as e:
                logger.warning(f"引用页码处理错误: {e}")
                total_count += 1

        return correct_count / total_count if total_count > 0 else 0.0

    def evaluate(self, file_path: str) -> Dict[str, float]:
        try:
            # 加载数据
            data = self.load_data(file_path)

            if not data:
                logger.warning("未加载到任何数据")
                return {}

            nlp_metrics = self.compute_nlp_metrics(data)

            ref_accuracy = self.compute_reference_accuracy(data)

            # 计算平均值
            results = {
                'avg_bleu': self._safe_average(nlp_metrics['bleu']),
                'avg_rouge1_r': self._safe_average(nlp_metrics['rouge1_r']),
                'avg_rouge2_r': self._safe_average(nlp_metrics['rouge2_r']),
                'reference_accuracy': ref_accuracy,
                'total_samples': len(data)
            }

            return results

        except Exception as e:
            logger.error(f"评估过程出错: {e}")
            return {}

    @staticmethod
    def _safe_average(scores: List[float]) -> float:
        """安全计算平均值"""
        return sum(scores) / len(scores) if scores else 0.0

    def print_results(self, results: Dict[str, float]) -> None:
        print("\n" + "=" * 50)
        print("RAG系统评估结果")
        print("=" * 50)
        print(f"平均 BLEU 分数:      {results.get('avg_bleu', 0):.4f}")
        print(f"平均 ROUGE-1 Recall: {results.get('avg_rouge1_r', 0):.4f}")
        print(f"平均 ROUGE-2 Recall: {results.get('avg_rouge2_r', 0):.4f}")
        print(f"引用页码命中率:      {results.get('reference_accuracy', 0):.2%}")
        print(f"评估样本总数:        {results.get('total_samples', 0)}")
        print("=" * 50)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='RAG系统评估工具')
    parser.add_argument(
        '--input_file',
        type=str,
        default='answers3.json',
        help='输入的JSON评估文件路径（默认为 my_answer.json）'
    )

    args = parser.parse_args()

    # 创建评估器
    evaluator = RAGEvaluator()

    try:
        # 执行评估
        results = evaluator.evaluate(args.input_file)
        # 打印结果
        evaluator.print_results(results)

    except FileNotFoundError:
        logger.error(f"数据文件不存在: {args.input_file}")
    except Exception as e:
        logger.error(f"程序执行失败: {e}")


if __name__ == "__main__":
    main()